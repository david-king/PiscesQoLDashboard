#! /bin/bash

if ! type jq >/dev/null 2>&1; then
  yum install -y jq
fi
crontab=$(cat /var/dashboard/statuses/sync_heart | jq '.crontab')
service=$(cat /var/dashboard/services/crontabsycn | tr -d '\n')

if [[ $service == 'enabled' ]]; then
  echo "$crontab /var/dashboard/api/survival.php" >> /var/spool/cron/root 2>&1
else
  sed -i '/survival.php/d' /var/spool/cron/root
fi
service cron restart