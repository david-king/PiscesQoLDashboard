<?php


class Api
{

    // 全局当前服务器心跳检查状态，-1：未添加心跳检查，0：心跳停止，1：心跳存活
    static $crondStatus = -1;

    /**
     * 添加crontab到中
     */
    function installCrond($crontab) {
        shell_exec($crontab." /var/dashboard/api/survival.php 2>&1 >> /var/spool/cron/root");
        shell_exec("service cron restart");
    }

    /**
     * 当前服务器心跳状态检查
     */
    function checkCrondStatus() {
        return Api::$crondStatus<=0?"停止":"存活";
    }

    /**
     * 同步心跳，向平台主动发送请求(表示我还存活)
     */
    function syncHeartbeat() {
        shell_exec("php /var/dashboard/api/survival.php");
    }

    function get($url){
        $headerArray =array("Content-type:application/json;","Accept:application/json");
        $ch = curl_init();
        curl_setopt($ch, CURLOPT_URL, $url);
        curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($ch, CURLOPT_SSL_VERIFYHOST, FALSE);
        curl_setopt($ch, CURLOPT_RETURNTRANSFER, 1);
        curl_setopt($ch,CURLOPT_HTTPHEADER,$headerArray);
        $output = curl_exec($ch);
        curl_close($ch);
        $output = json_decode($output,true);
        return $output;
    }

    function post($url,$data){
        $data  = json_encode($data);
        $headerArray =array("Content-type:application/json;charset='utf-8'","Accept:application/json");
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST,FALSE);
        curl_setopt($curl, CURLOPT_POST, 1);
        curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        curl_setopt($curl,CURLOPT_HTTPHEADER,$headerArray);
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return json_decode($output,true);
    }

}