<?php


//$config = json_decode('{"url":"http:\/\/192.168.31.142:8000\/api\/hntSync\/notify","crontab":"*\/1 * * * *"}', true);
//echo $config['url'];

$config = json_encode([
    'url' => 'http://192.168.31.142:8000/api/hntSync/notify',
    'crontab' => ''
], JSON_UNESCAPED_UNICODE);
echo $config;

$json = json_decode($config, true);
echo $json['url'];

//echo time();
