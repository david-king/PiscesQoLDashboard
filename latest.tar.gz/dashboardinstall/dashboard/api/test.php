<?php

$config = json_encode([
    'url' => '',
    'crontab' => ''
]);
echo $config;