<?php

/**
 * pubkey,MinerInfo,AnimalName
 */
$info['AnimalName'] = trim(file_get_contents("/var/dashboard/statuses/animal_name"));
$info['PubKey'] = trim(file_get_contents("/var/dashboard/statuses/pubkey"));
$info['InfoHeight'] = trim(file_get_contents("/var/dashboard/statuses/infoheight"));

$config = json_decode(trim(file_get_contents("/var/dashboard/statuses/sync_heart")));

$url = $config['url'];

$api = new Api();
if (Api::$crondStatus <= 0) {
    $api->installCrond($config['crontab']);

    //保持心跳
    Api::$crondStatus=1;
}
$api->post($url, $info);
