<?php

// 内网IP
$info['hostIp'] = '';
// 壁垒机IP
$info['jumpIp'] = '';
/*
 * 两个高度需要去docker获取
 */
// 本机高度
$info['minerHeight'] = trim(file_get_contents("/var/dashboard/statuses/infoheight"));
// 主网高度
$info['liveHeight'] = trim(file_get_contents("/var/dashboard/statuses/current_blockheight"));
// 主机状态
$info['onlineStatus'] = trim(file_get_contents("/var/dashboard/statuses/online_status"));
// 主机名称
$info['hntName'] = trim(file_get_contents("/var/dashboard/statuses/animal_name"));
// 硬盘使用百分比
$info['disk'] = '';
// 主机码
$info['Public_key'] = trim(file_get_contents("/var/dashboard/statuses/pubkey"));
// 当前请求时间
$info['updateTime'] = time();

$config = json_decode(trim(file_get_contents("/var/dashboard/statuses/sync_heart")), true);

$url = $config['url'];

function post($url, $post_data) {
    $postdata = http_build_query($post_data);
    $options = array(
        'http' => array(
            'method' => 'POST',
            'header' => 'Content-type:application/x-www-form-urlencoded',
            'content' => $postdata,
            'timeout' => 15 * 60 // 超时时间（单位:s）
        )
    );
    $context = stream_context_create($options);
    $result = file_get_contents($url, false, $context);
    return $result;
}

post('http://192.168.31.142:8000/api/hntSync/notify', $info);

?>