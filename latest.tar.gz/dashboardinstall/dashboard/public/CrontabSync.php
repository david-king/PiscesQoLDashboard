<?php

$status = strip_tags(htmlentities($_GET['status']));
$info = json_decode(trim(file_get_contents('/var/dashboard/statuses/sync_heart')));

if ((isset($info['url']) && isset($info['crontab'])) && ($info['url'] != '' && $info['crontab'] != "")) {
    switch ($status) {
        // 开
        case 'enabled':
            $file = fopen('/var/dashboard/services/crontabsycn', 'w');
            fwrite($file, "enabled\n");
            fclose($file);

            shell_exec("echo '".$info['crontab']." /var/dashboard/api/survival.php' >> /var/spool/cron/root 2>&1");
            break;
        // 关
        case 'disabled':
            $file = fopen('/var/dashboard/services/crontabsycn', 'w');
            fwrite($file, "disabled\n");
            fclose($file);

            shell_exec("sed -i '/survival.php/d' /var/spool/cron/root");
            break;
    }
    shell_exec("service cron restart");
    echo 'ok';
} else {
    echo 'please setting up Sync Heart Data';

}
