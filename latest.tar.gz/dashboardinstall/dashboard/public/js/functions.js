function DisableService(ServiceName)
{
	httpRequest = new XMLHttpRequest();
	httpRequest.open('GET', 'DisableService.php?action='+ServiceName, true);
	httpRequest.send();
}

function EnableService(ServiceName)
{
	httpRequest = new XMLHttpRequest();
	httpRequest.open('GET', 'EnableService.php?action='+ServiceName, true);
	httpRequest.send();

	if(ServiceName == 'FastSync')
	{
		httpRequest.onreadystatechange = function() {
			if(httpRequest.readyState == 4 && httpRequest.status == 200) {
				location.reload();
			}
		}
	}
}

function RebootDevice()
{
	httpRequest = new XMLHttpRequest();
	httpRequest.open('GET', 'RebootDevice.php', true);
	httpRequest.send();

	window.location.href = "/index.php?page=rebooting";
}

function ResetPasswordPrompt()
{
	var passwordbox = document.createElement("div");
	passwordbox.className = "closeable_prompt_overlay";
	passwordbox.innerHTML = '<div id="closeable_prompt"><div id="prompt_title"><h2>Reset Password</h2><button type="button" onclick="ClosePrompt()" value="Close" title="Close" id="CloseButton">X</button></div><div id="prompt_body"><div id="inputs"><label for="password">Password:</label><input type="password" id="password" name="password"><br /><label for="confirm_password">Confirm Password:</label><input type="password" name="confirm_password" id="confirm_password" /></div></div><div id="prompt_footer"><button id="reset_password_button" onclick="ResetPassword()"; type="button">Submit</button></div></div>';
	var body = document.body.appendChild(passwordbox);
}

function ResetPassword()
{
	var password = document.getElementById("password").value;
	var confirmpassword = document.getElementById("confirm_password").value;
	var params = 'password='+password+'&confirmpassword='+confirmpassword;
	httpRequest = new XMLHttpRequest();
	httpRequest.open('POST', 'ResetPassword.php', true);
	httpRequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	httpRequest.onreadystatechange = function() {
		if(httpRequest.readyState == 4 && httpRequest.status == 200) {
			alert(httpRequest.responseText);
			var password_box = document.getElementById("password_prompt_overlay");
			password_box.remove();
		}
	}

	httpRequest.send(params);
}

function SetWirelessPrompt()
{
	var wirelessbox = document.createElement("div");
	wirelessbox.className = "closeable_prompt_overlay";
	wirelessbox.innerHTML = '<div id="closeable_prompt"><div id="prompt_title"><h2>Set WiFi Details</h2><button type="button" onclick="ClosePrompt()" value="Close" title="Close" id="CloseButton">X</button></div><div id="prompt_body"><div id="inputs"><label for="SSID">SSID:</label><input type="text" id="SSID" name="SSID" /><br /><label for="password">Password:</label><input type="password" id="password" name="password" /><br /><label for="country">Country:</label><select id="country" name="country"><option></option><option value="AF">Afghanistan</option><option value="AX">Aland Islands</option><option value="AL">Albania</option><option value="DZ">Algeria</option><option value="AS">American Samoa</option><option value="AD">Andorra</option><option value="AO">Angola</option><option value="AI">Anguilla</option><option value="AQ">Antarctica</option><option value="AG">Antigua and Barbuda</option><option value="AR">Argentina</option><option value="AM">Armenia</option><option value="AW">Aruba</option><option value="AU">Australia</option><option value="AT">Austria</option><option value="AZ">Azerbaijan</option><option value="BS">Bahamas</option><option value="BH">Bahrain</option><option value="BD">Bangladesh</option><option value="BB">Barbados</option><option value="BY">Belarus</option><option value="BE">Belgium</option><option value="BZ">Belize</option><option value="BJ">Benin</option><option value="BM">Bermuda</option><option value="BT">Bhutan</option><option value="BO">Bolivia</option><option value="BQ">Bonaire, Sint Eustatius and Saba</option><option value="BA">Bosnia and Herzegovina</option><option value="BW">Botswana</option><option value="BV">Bouvet Island</option><option value="BR">Brazil</option><option value="IO">British Indian Ocean Territory</option><option value="BN">Brunei Darussalam</option><option value="BG">Bulgaria</option><option value="BF">Burkina Faso</option><option value="BI">Burundi</option><option value="KH">Cambodia</option><option value="CM">Cameroon</option><option value="CA">Canada</option><option value="CV">Cape Verde</option><option value="KY">Cayman Islands</option><option value="CF">Central African Republic</option><option value="TD">Chad</option><option value="CL">Chile</option><option value="CN">China</option><option value="CX">Christmas Island</option><option value="CC">Cocos (Keeling) Islands</option><option value="CO">Colombia</option><option value="KM">Comoros</option><option value="CG">Congo</option><option value="CD">Congo, Democratic Republic of the Congo</option><option value="CK">Cook Islands</option><option value="CR">Costa Rica</option><option value="CI">Cote D\'Ivoire</option><option value="HR">Croatia</option><option value="CU">Cuba</option><option value="CW">Curacao</option><option value="CY">Cyprus</option><option value="CZ">Czech Republic</option><option value="DK">Denmark</option><option value="DJ">Djibouti</option><option value="DM">Dominica</option><option value="DO">Dominican Republic</option><option value="EC">Ecuador</option><option value="EG">Egypt</option><option value="SV">El Salvador</option><option value="GQ">Equatorial Guinea</option><option value="ER">Eritrea</option><option value="EE">Estonia</option><option value="ET">Ethiopia</option><option value="FK">Falkland Islands (Malvinas)</option><option value="FO">Faroe Islands</option><option value="FJ">Fiji</option><option value="FI">Finland</option><option value="FR">France</option><option value="GF">French Guiana</option><option value="PF">French Polynesia</option><option value="TF">French Southern Territories</option><option value="GA">Gabon</option><option value="GM">Gambia</option><option value="GE">Georgia</option><option value="DE">Germany</option><option value="GH">Ghana</option><option value="GI">Gibraltar</option><option value="GR">Greece</option><option value="GL">Greenland</option><option value="GD">Grenada</option><option value="GP">Guadeloupe</option><option value="GU">Guam</option><option value="GT">Guatemala</option><option value="GG">Guernsey</option><option value="GN">Guinea</option><option value="GW">Guinea-Bissau</option><option value="GY">Guyana</option><option value="HT">Haiti</option><option value="HM">Heard Island and Mcdonald Islands</option><option value="VA">Holy See (Vatican City State)</option><option value="HN">Honduras</option><option value="HK">Hong Kong</option><option value="HU">Hungary</option><option value="IS">Iceland</option><option value="IN">India</option><option value="ID">Indonesia</option><option value="IR">Iran, Islamic Republic of</option><option value="IQ">Iraq</option><option value="IE">Ireland</option><option value="IM">Isle of Man</option><option value="IL">Israel</option><option value="IT">Italy</option><option value="JM">Jamaica</option><option value="JP">Japan</option><option value="JE">Jersey</option><option value="JO">Jordan</option><option value="KZ">Kazakhstan</option><option value="KE">Kenya</option><option value="KI">Kiribati</option><option value="KP">Korea, Democratic People\'s Republic of</option><option value="KR">Korea, Republic of</option><option value="XK">Kosovo</option><option value="KW">Kuwait</option><option value="KG">Kyrgyzstan</option><option value="LA">Lao People\'s Democratic Republic</option><option value="LV">Latvia</option><option value="LB">Lebanon</option><option value="LS">Lesotho</option><option value="LR">Liberia</option><option value="LY">Libyan Arab Jamahiriya</option><option value="LI">Liechtenstein</option><option value="LT">Lithuania</option><option value="LU">Luxembourg</option><option value="MO">Macao</option><option value="MK">Macedonia, the Former Yugoslav Republic of</option><option value="MG">Madagascar</option><option value="MW">Malawi</option><option value="MY">Malaysia</option><option value="MV">Maldives</option><option value="ML">Mali</option><option value="MT">Malta</option><option value="MH">Marshall Islands</option><option value="MQ">Martinique</option><option value="MR">Mauritania</option><option value="MU">Mauritius</option><option value="YT">Mayotte</option><option value="MX">Mexico</option><option value="FM">Micronesia, Federated States of</option><option value="MD">Moldova, Republic of</option><option value="MC">Monaco</option><option value="MN">Mongolia</option><option value="ME">Montenegro</option><option value="MS">Montserrat</option><option value="MA">Morocco</option><option value="MZ">Mozambique</option><option value="MM">Myanmar</option><option value="NA">Namibia</option><option value="NR">Nauru</option><option value="NP">Nepal</option><option value="NL">Netherlands</option><option value="AN">Netherlands Antilles</option><option value="NC">New Caledonia</option><option value="NZ">New Zealand</option><option value="NI">Nicaragua</option><option value="NE">Niger</option><option value="NG">Nigeria</option><option value="NU">Niue</option><option value="NF">Norfolk Island</option><option value="MP">Northern Mariana Islands</option><option value="NO">Norway</option><option value="OM">Oman</option><option value="PK">Pakistan</option><option value="PW">Palau</option><option value="PS">Palestinian Territory, Occupied</option><option value="PA">Panama</option><option value="PG">Papua New Guinea</option><option value="PY">Paraguay</option><option value="PE">Peru</option><option value="PH">Philippines</option><option value="PN">Pitcairn</option><option value="PL">Poland</option><option value="PT">Portugal</option><option value="PR">Puerto Rico</option><option value="QA">Qatar</option><option value="RE">Reunion</option><option value="RO">Romania</option><option value="RU">Russian Federation</option><option value="RW">Rwanda</option><option value="BL">Saint Barthelemy</option><option value="SH">Saint Helena</option><option value="KN">Saint Kitts and Nevis</option><option value="LC">Saint Lucia</option><option value="MF">Saint Martin</option><option value="PM">Saint Pierre and Miquelon</option><option value="VC">Saint Vincent and the Grenadines</option><option value="WS">Samoa</option><option value="SM">San Marino</option><option value="ST">Sao Tome and Principe</option><option value="SA">Saudi Arabia</option><option value="SN">Senegal</option><option value="RS">Serbia</option><option value="CS">Serbia and Montenegro</option><option value="SC">Seychelles</option><option value="SL">Sierra Leone</option><option value="SG">Singapore</option><option value="SX">Sint Maarten</option><option value="SK">Slovakia</option><option value="SI">Slovenia</option><option value="SB">Solomon Islands</option><option value="SO">Somalia</option><option value="ZA">South Africa</option><option value="GS">South Georgia and the South Sandwich Islands</option><option value="SS">South Sudan</option><option value="ES">Spain</option><option value="LK">Sri Lanka</option><option value="SD">Sudan</option><option value="SR">Suriname</option><option value="SJ">Svalbard and Jan Mayen</option><option value="SZ">Swaziland</option><option value="SE">Sweden</option><option value="CH">Switzerland</option><option value="SY">Syrian Arab Republic</option><option value="TW">Taiwan, Province of China</option><option value="TJ">Tajikistan</option><option value="TZ">Tanzania, United Republic of</option><option value="TH">Thailand</option><option value="TL">Timor-Leste</option><option value="TG">Togo</option><option value="TK">Tokelau</option><option value="TO">Tonga</option><option value="TT">Trinidad and Tobago</option><option value="TN">Tunisia</option><option value="TR">Turkey</option><option value="TM">Turkmenistan</option><option value="TC">Turks and Caicos Islands</option><option value="TV">Tuvalu</option><option value="UG">Uganda</option><option value="UA">Ukraine</option><option value="AE">United Arab Emirates</option><option value="GB">United Kingdom</option><option value="US">United States</option><option value="UM">United States Minor Outlying Islands</option><option value="UY">Uruguay</option><option value="UZ">Uzbekistan</option><option value="VU">Vanuatu</option><option value="VE">Venezuela</option><option value="VN">Viet Nam</option><option value="VG">Virgin Islands, British</option><option value="VI">Virgin Islands, U.s.</option><option value="WF">Wallis and Futuna</option><option value="EH">Western Sahara</option><option value="YE">Yemen</option><option value="ZM">Zambia</option><option value="ZW">Zimbabwe</option></select></div></div><div id="prompt_footer"><button id="set_wifi_button" onclick="SetWireless()"; type="button">Submit</button></div>';

	document.body.appendChild(wirelessbox);
}


function SetWireless()
{
	var ssid = document.getElementById("SSID").value;
	var password = document.getElementById("password").value;
	var country = document.getElementById("country").value;
	var params = 'SSID='+ssid+'&password='+password+'&country='+country;
	httpRequest = new XMLHttpRequest();
	httpRequest.open('POST', 'SetWireless.php', true);
	httpRequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	httpRequest.onreadystatechange = function() {
		if(httpRequest.readyState == 4 && httpRequest.status == 200) {
			alert(httpRequest.responseText);
			var prompt = document.getElementsByClassName("closeable_prompt_overlay");
			prompt[0].remove();
		}
	}

	httpRequest.send(params);
}


function StartMinerUpdate()
{
	httpRequest = new XMLHttpRequest();
	httpRequest.open('GET', '/index.php?page=updateminer&start=true', true);
	httpRequest.send();

	serviceRequest = new XMLHttpRequest();
	serviceRequest.open('GET', 'services.php?name=miner-update', true);
	serviceRequest.send();
	var logRefresh = setInterval(function() {
		serviceRequest.open('GET', 'services.php?name=miner-update', true);
		serviceRequest.send();
		serviceRequest.onreadystatechange = function() {


			if(serviceRequest.readyState == 4 && serviceRequest.status == 200)
			{
				logRequest = new XMLHttpRequest();
				logRequest.open('GET', 'logs.php?name=miner-update', true);
				logRequest.send();

				logRequest.onreadystatechange = function() {
					if(logRequest.readyState == 4 && logRequest.status == 200)
					{
						document.getElementById("log_output").innerHTML = logRequest.responseText;
					}
				}

				if(serviceRequest.responseText == 'stopped')
				{
					clearInterval(logRefresh);
				}
			}
		}
	}, 1000)
}


function StartDashboardUpdate()
{
	httpRequest = new XMLHttpRequest();
	httpRequest.open('GET', '/index.php?page=updatedashboard&start=true', true);
	httpRequest.send();

	serviceRequest = new XMLHttpRequest();
	serviceRequest.open('GET', 'services.php?name=dashboard-update', true);
	serviceRequest.send();
	var logRefresh = setInterval(function() {
		serviceRequest.open('GET', 'services.php?name=dashboard-update', true);
		serviceRequest.send();
		serviceRequest.onreadystatechange = function() {
			if(serviceRequest.readyState == 4 && serviceRequest.status == 200)
			{
				logRequest = new XMLHttpRequest();
				logRequest.open('GET', 'logs.php?name=dashboard-update', true);
				logRequest.send();

				logRequest.onreadystatechange = function() {
					if(logRequest.readyState == 4 && logRequest.status == 200)
					{
						document.getElementById("log_output").innerHTML = logRequest.responseText;
					}
				}

				if(serviceRequest.responseText == 'stopped')
				{
					clearInterval(logRefresh);
				}
			}
		}
	}, 1000)
}


function ClearBlockChainPrompt()
{
	var prompt = document.createElement("div");
	prompt.className = "closeable_prompt_overlay";
	prompt.innerHTML = '<div id="closeable_prompt"><div id="prompt_title"><h2>Clear BlockChain Data</h2><button type="button" onclick="ClosePrompt()" value="Close" title="Close" id="CloseButton">X</button></div><div id="prompt_body"><p>Are you sure you wish to clear your blockchain data?</p><p>You will have to re-sync.</p><p>You should only do this if your miner docker fails to start or your disk usage is high.</p></div><div id="prompt_footer"><button type="button" value="Yes" title="Yes" id="blockchain_clear_yes" onclick="ClearBlockChainRedirect()">Yes</button><button value="No" title="No" type="button" id="blockchain_clear_no" onclick="ClosePrompt()">No</button></div>'

	document.body.appendChild(prompt);
}


function StartBlockChainClear()
{
	httpRequest = new XMLHttpRequest();
	httpRequest.open('GET', '/index.php?page=clearblockchain&start=true', true);
	httpRequest.send();

	serviceRequest = new XMLHttpRequest();
	serviceRequest.open('GET', 'services.php?name=clear-blockchain', true);
	serviceRequest.send();
	var logRefresh = setInterval(function() {
		serviceRequest.open('GET', 'services.php?name=clear-blockchain', true);
		serviceRequest.send();
		serviceRequest.onreadystatechange = function() {
			if(serviceRequest.readyState == 4 && serviceRequest.status == 200)
			{
				logRequest = new XMLHttpRequest();
				logRequest.open('GET', 'logs.php?name=clear-blockchain', true);
				logRequest.send();

				logRequest.onreadystatechange = function() {
					if(logRequest.readyState == 4 && logRequest.status == 200)
					{
						document.getElementById("log_output").innerHTML = logRequest.responseText;
						document.getElementById("log_output").scrollTop = document.getElementById("log_output").scrollHeight
					}
				}

				if(serviceRequest.responseText == 'stopped')
				{
					clearInterval(logRefresh);
				}
			}
		}
	}, 1000)
}


function ClearBlockChainRedirect()
{
	window.location.replace("/index.php?page=clearblockchain");
}

function ClosePrompt()
{
	var prompt = document.getElementsByClassName("closeable_prompt_overlay");
	prompt[0].remove();
}

function SetSyncHeartPrompt(url, crontab)
{
	var syncheartbox = document.createElement("div");
	syncheartbox.className = "closeable_prompt_overlay";
	syncheartbox.innerHTML = '<div id="closeable_prompt"><div id="prompt_title"><h2>Set Sycn Heart</h2><button type="button" onclick="ClosePrompt()" value="Close" title="Close" id="CloseButton">X</button></div><div id="prompt_body"><div id="inputs"><label for="url">url:</label><input type="text" id="url" name="url" value="'+url+'" /><br /><label for="crontab">crontab:</label><input type="text" id="crontab" name="crontab" value="'+crontab+'" /></div></div><div id="prompt_footer"><button id="set_heart_button" onclick="SetSyncHeart()" ; type="button">Submit</button></div>';

	document.body.appendChild(syncheartbox);
}

function SetSyncHeart()
{
	var url = document.getElementById("url").value;
	var crontab = document.getElementById("crontab").value;
	var params = 'url='+url+'&crontab='+crontab;
	httpRequest = new XMLHttpRequest();
	httpRequest.open('POST', 'SetSyncHeart.php', true);
	httpRequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	httpRequest.onreadystatechange = function() {
		if(httpRequest.readyState == 4 && httpRequest.status == 200) {
			alert(httpRequest.responseText);
			var prompt = document.getElementsByClassName("closeable_prompt_overlay");
			prompt[0].remove();
			location.reload();
		}
	}

	httpRequest.send(params);
}

function CrontabSync(status)
{
	httpRequest = new XMLHttpRequest();
	httpRequest.open('GET', 'CrontabSync.php?status='+status, true);
	httpRequest.send();
	httpRequest.onreadystatechange = function() {
		if(httpRequest.readyState == 4 && httpRequest.status == 200) {
			location.reload();
		}
	}
}

function SetFastSyncLocalhostPrompt(data)
{
	var div = document.createElement("div");
	div.className = "closeable_prompt_overlay";
	div.innerHTML = '<div id="closeable_prompt"><div id="prompt_title"><h2>Set Fast Sync Localhost</h2><button type="button" onclick="ClosePrompt()" value="Close" title="Close" id="CloseButton">X</button></div><div id="prompt_body"><div id="inputs"><label for="file_url">file_url:</label><input type="text" id="file_url" name="file_url" value="'+data+'" /></div></div><div id="prompt_footer"><button id="set_file_path_button" onclick="SetFastSyncLocalhost()" ; type="button">Submit</button><button id="sync_button" onclick="FastSyncLocalhost()" ; type="button">start</button></div>';

	document.body.appendChild(div);
}

function SetFastSyncLocalhost()
{
	var file_url = document.getElementById("file_url").value;
	var params = 'file_url='+file_url;
	httpRequest = new XMLHttpRequest();
	httpRequest.open('POST', 'SetFastSyncLocalhost.php', true);
	httpRequest.setRequestHeader('Content-type', 'application/x-www-form-urlencoded');
	httpRequest.onreadystatechange = function() {
		if(httpRequest.readyState == 4 && httpRequest.status == 200) {
			alert(httpRequest.responseText);
			var prompt = document.getElementsByClassName("closeable_prompt_overlay");
			prompt[0].remove();
			location.reload();
		}
	}

	httpRequest.send(params);
}

function FastSyncLocalhost()
{
	httpRequest = new XMLHttpRequest();
	httpRequest.open('POST', 'FastSyncLocalhost.php', true);
	httpRequest.onreadystatechange = function() {
		if(httpRequest.readyState == 4 && httpRequest.status == 200) {
			if(httpRequest.responseText.indexOf('Error') != -1) {
				alert(httpRequest.responseText);
			} else {
				location.reload();
			}
		}
	}
	httpRequest.send();
}
