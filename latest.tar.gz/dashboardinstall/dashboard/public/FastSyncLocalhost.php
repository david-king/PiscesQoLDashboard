<?php
    $file = fopen('/var/dashboard/services/fastsync_localhost', 'w');
    fwrite($file, "start\n");
    fclose($file);
?>