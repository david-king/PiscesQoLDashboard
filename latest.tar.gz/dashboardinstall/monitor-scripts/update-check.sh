#!/bin/bash
wget --no-cache https://raw.githubusercontent.com/briffy/PiscesQoLDashboard/main/version -O /var/dashboard/update
